create definer = root@localhost view tea_ap as
select `people`.`award_punish`.`ap_id`      AS `ap_id`,
       `people`.`award_punish`.`teacher_id` AS `teacher_id`,
       `people`.`teacher`.`tea_name`        AS `tea_name`,
       `people`.`ap_type`.`ap_type`         AS `ap_type`,
       `people`.`award_punish`.`time`       AS `time`,
       `people`.`award_punish`.`desc`       AS `desc`
from (`people`.`ap_type`
         left join (`people`.`award_punish` left join `people`.`teacher` on ((`people`.`teacher`.`tea_id` = `people`.`award_punish`.`teacher_id`)))
                   on ((`people`.`award_punish`.`type` = `people`.`ap_type`.`ap_id`)))
order by `people`.`award_punish`.`teacher_id`;

