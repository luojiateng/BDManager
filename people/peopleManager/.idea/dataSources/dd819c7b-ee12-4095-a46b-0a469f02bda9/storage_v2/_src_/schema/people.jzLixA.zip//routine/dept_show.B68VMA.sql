create
    definer = root@localhost procedure dept_show(IN deptName varchar(30))
begin
    select dep_id, depName, titleName, count(*) as titNumber
    from teacher
             right join title t on t.titleId = teacher.title_id
             right join dept d on d.dep_id = teacher.dept_id
    where depName = deptName
    group by t.titleName;
end;

