create definer = root@localhost trigger delete_stu_number
    after delete
    on student
    for each row
begin
    update classinfo set stu_number=stu_number - 1 where class_id = OLD.class_id;
end;

