create definer = root@localhost trigger gender__check
    before insert
    on student
    for each row
begin
    if (new.gender = '女' or new.gender = '男') then
        set new.gender = new.gender;
    else
        set new.gender = 'null';
    end if;
end;

