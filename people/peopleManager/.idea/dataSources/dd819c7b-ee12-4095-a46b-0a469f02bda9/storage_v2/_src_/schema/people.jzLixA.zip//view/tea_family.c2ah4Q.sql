create definer = root@localhost view tea_family as
select `people`.`teacher`.`tea_id`         AS `tea_id`,
       `people`.`teacher`.`tea_name`       AS `tea_name`,
       `people`.`fam_type`.`fam_type_name` AS `fam_type_name`,
       `people`.`family`.`memer_name`      AS `member_name`
from (`people`.`fam_type`
         left join (`people`.`family` left join `people`.`teacher` on ((`people`.`teacher`.`tea_id` = `people`.`family`.`teacher_id`)))
                   on ((`people`.`fam_type`.`fam_id` = `people`.`family`.`home_member`)))
order by `people`.`family`.`teacher_id`;

-- comment on column tea_family.fam_type_name not supported: 成员名称

