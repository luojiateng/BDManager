create
    definer = root@localhost procedure faculty_show()
begin
    select faculty_id, faculty_name, al.acount as stuCount, g.gcount as girlCount, b.bcount as boyCount
    from faculty
             right outer join (select count(*) as acount, f.faculty_id as aid
                               from student s
                                        inner join classinfo c on c.class_id = s.class_id
                                        inner join major m on m.major_id = c.major_id
                                        inner join faculty f on f.faculty_id = m.faculty_id
                               group by f.faculty_id) al
                              on al.aid = faculty.faculty_id
             right outer join (select count(*) as bcount, f.faculty_id as bid
                               from student s
                                        inner join classinfo c on c.class_id = s.class_id
                                        inner join major m on m.major_id = c.major_id
                                        inner join faculty f on f.faculty_id = m.faculty_id
                               where s.gender = '男'
                               group by f.faculty_id) b
                              on b.bid = faculty.faculty_id
             right outer join (select count(*) as gcount, f.faculty_id as gid
                               from student s
                                        inner join classinfo c on c.class_id = s.class_id
                                        inner join major m on m.major_id = c.major_id
                                        inner join faculty f on f.faculty_id = m.faculty_id
                               where s.gender = '女'
                               group by f.faculty_id) g
                              on g.gid = faculty.faculty_id
    order by faculty_id;
end;

