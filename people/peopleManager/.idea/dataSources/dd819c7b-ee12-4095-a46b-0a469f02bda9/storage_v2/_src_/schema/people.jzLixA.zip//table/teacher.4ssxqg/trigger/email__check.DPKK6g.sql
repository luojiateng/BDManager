create definer = root@localhost trigger email__check
    before insert
    on teacher
    for each row
begin
    if (new.email regexp '^[a-z0-9A-Z]+[- | a-z0-9A-Z . _]+@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?\\.)+[a-z]{2,}$') then
        set new.email = new.email;
    else
        set new.email = 'null';
    end if;
end;

