create definer = root@localhost view stu_punish as
select `stu`.`stu_id` AS `stu_id`, `stu`.`stu_name` AS `stu_name`, `p`.`time` AS `time`, `p`.`desc` AS `desc`
from (`abc`.`student` `stu`
         join `abc`.`punish` `p` on ((`stu`.`stu_id` = `p`.`stu_id`)));

