create definer = root@localhost trigger delete_teaNumber
    after delete
    on teacher
    for each row
begin
    update dept set teaNum=dept.teaNum - 1 where dep_id = OLD.dept_id;
end;

