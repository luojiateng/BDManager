create definer = root@localhost view stu_award as
select `stu`.`stu_id` AS `stu_id`, `stu`.`stu_name` AS `stu_name`, `a`.`time` AS `time`, `a`.`desc` AS `desc`
from (`abc`.`student` `stu`
         join `abc`.`award` `a` on ((`stu`.`stu_id` = `a`.`stu_id`)));

