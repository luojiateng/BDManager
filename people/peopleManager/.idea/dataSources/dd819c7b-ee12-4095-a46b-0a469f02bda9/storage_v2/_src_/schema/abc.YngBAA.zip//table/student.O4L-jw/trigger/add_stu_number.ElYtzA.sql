create definer = root@localhost trigger add_stu_number
    after insert
    on student
    for each row
begin
    update classinfo set stu_number=stu_number + 1 where class_id = NEW.class_id;
end;

