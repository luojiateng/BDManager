create definer = root@localhost view tea_education as
select `people`.`tea_edu`.`tea_id`    AS `tea_id`,
       `people`.`teacher`.`tea_name`  AS `tea_name`,
       `s`.`school_name`              AS `school_name`,
       `people`.`edu_type`.`edu_name` AS `edu_name`,
       `people`.`tea_edu`.`btime`     AS `btime`,
       `people`.`tea_edu`.`etime`     AS `etime`
from (`people`.`school` `s`
         left join (`people`.`edu_type` left join (`people`.`tea_edu` left join `people`.`teacher` on ((`people`.`teacher`.`tea_id` = `people`.`tea_edu`.`tea_id`))) on ((`people`.`edu_type`.`edu_id` = `people`.`tea_edu`.`edu_type`)))
                   on ((`people`.`tea_edu`.`school_id` = `s`.`school_id`)))
order by `people`.`tea_edu`.`tea_id`;

