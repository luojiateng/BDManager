create definer = root@localhost view tea_dept as
select `people`.`teacher`.`tea_id`       AS `tea_id`,
       `people`.`teacher`.`tea_name`     AS `tea_name`,
       `people`.`teacher`.`gender`       AS `gender`,
       `people`.`teacher`.`email`        AS `email`,
       `people`.`dept`.`depName`         AS `depName`,
       `people`.`title`.`titleName`      AS `titleName`,
       `people`.`postion`.`positionName` AS `positionName`
from (((`people`.`teacher` join `people`.`dept` on ((`people`.`dept`.`dep_id` = `people`.`teacher`.`dept_id`))) join `people`.`title` on ((`people`.`title`.`titleId` = `people`.`teacher`.`title_id`)))
         join `people`.`postion` on ((`people`.`postion`.`positionId` = `people`.`teacher`.`postion_id`)))
order by `people`.`teacher`.`tea_id`;

