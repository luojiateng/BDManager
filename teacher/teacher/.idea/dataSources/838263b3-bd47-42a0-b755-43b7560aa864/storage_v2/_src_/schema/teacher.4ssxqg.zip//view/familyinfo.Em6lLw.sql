create definer = root@localhost view familyinfo as
select `teacher`.`teacher`.`teacherNumber` AS `teacherNumber`,
       `teacher`.`teacher`.`teacherName`   AS `teacherName`,
       `teacher`.`relation`.`familys`      AS `familys`,
       `f`.`fName`                         AS `fName`
from (`teacher`.`relation`
         left join (`teacher`.`teacher` join `teacher`.`family` `f` on ((`f`.`teacherNumber` = `teacher`.`teacher`.`teacherNumber`)))
                   on ((`teacher`.`relation`.`relationNumber` = `f`.`relation`)))
order by `teacher`.`teacher`.`teacherNumber`;

-- comment on column familyinfo.familys not supported: 成员名称

