create definer = root@localhost trigger add_teaNumber
    after insert
    on teacher
    for each row
begin
    update department set teacherNum=teacherNum + 1 where deptNumber = NEW.deptNumber;
end;

