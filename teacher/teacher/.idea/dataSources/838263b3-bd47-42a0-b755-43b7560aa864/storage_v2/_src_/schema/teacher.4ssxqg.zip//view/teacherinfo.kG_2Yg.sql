create definer = root@localhost view teacherinfo as
select `teacher`.`teacher`.`teacherNumber` AS `teacherNumber`,
       `teacher`.`teacher`.`teacherName`   AS `teacherName`,
       `teacher`.`teacher`.`gender`        AS `gender`,
       `teacher`.`teacher`.`birth`         AS `birth`,
       `teacher`.`teacher`.`email`         AS `email`,
       `t`.`titleName`                     AS `titleName`,
       `d`.`deptName`                      AS `deptName`,
       `p`.`positionName`                  AS `positionName`
from (((`teacher`.`teacher` join `teacher`.`department` `d` on ((`teacher`.`teacher`.`deptNumber` = `d`.`deptNumber`))) join `teacher`.`position` `p` on ((`teacher`.`teacher`.`postionNumber` = `p`.`positionNumber`)))
         join `teacher`.`title` `t` on ((`teacher`.`teacher`.`titleNumber` = `t`.`titleNumber`)));

