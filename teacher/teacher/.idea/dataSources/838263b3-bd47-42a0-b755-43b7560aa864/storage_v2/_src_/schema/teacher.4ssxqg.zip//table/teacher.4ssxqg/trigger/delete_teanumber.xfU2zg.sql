create definer = root@localhost trigger delete_teaNumber
    after delete
    on teacher
    for each row
begin
    update department set teacherNum=teacherNum - 1 where deptNumber = OLD.deptNumber;
end;

