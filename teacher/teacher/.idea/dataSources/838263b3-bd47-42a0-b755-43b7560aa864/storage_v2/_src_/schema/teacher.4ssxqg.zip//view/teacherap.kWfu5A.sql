create definer = root@localhost view teacherap as
select `ap`.`apNumber`                     AS `apNumber`,
       `teacher`.`teacher`.`teacherNumber` AS `teacherNumber`,
       `teacher`.`teacher`.`teacherName`   AS `teacherName`,
       `ap`.`type`                         AS `type`,
       `ap`.`time`                         AS `time`,
       `ap`.`describe`                     AS `describe`
from (`teacher`.`teacher`
         join `teacher`.`award_punish` `ap` on ((`teacher`.`teacher`.`teacherNumber` = `ap`.`teacherNumber`)))
order by `ap`.`apNumber`;

