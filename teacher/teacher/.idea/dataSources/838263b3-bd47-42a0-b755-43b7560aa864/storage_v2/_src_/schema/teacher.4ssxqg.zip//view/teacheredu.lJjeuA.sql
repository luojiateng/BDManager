create definer = root@localhost view teacheredu as
select `teacher`.`teacher`.`teacherNumber` AS `teacherNumber`,
       `teacher`.`teacher`.`teacherName`   AS `teacherName`,
       `e`.`eduName`                       AS `eduName`,
       `ee`.`begin`                        AS `begin`,
       `ee`.`end`                          AS `end`,
       `s`.`schoolName`                    AS `schoolName`
from (((`teacher`.`teacher` join `teacher`.`education_exper` `ee` on ((`teacher`.`teacher`.`teacherNumber` = `ee`.`teacherNumber`))) join `teacher`.`education` `e` on ((`ee`.`educationNumber` = `e`.`eduNumber`)))
         join `teacher`.`school` `s` on ((`ee`.`schoolNumber` = `s`.`schoolNumber`)))
order by `teacher`.`teacher`.`teacherNumber`;

