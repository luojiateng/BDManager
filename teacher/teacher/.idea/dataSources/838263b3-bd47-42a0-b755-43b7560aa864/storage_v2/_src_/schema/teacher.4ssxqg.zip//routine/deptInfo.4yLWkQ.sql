create
    definer = root@localhost procedure deptInfo(IN IndeptName varchar(30))
begin
    select d.deptNumber, deptName, titleName, count(*) as titleCount
    from teacher
             right join title t on teacher.titleNumber = t.titleNumber
             right join department d on d.deptNumber = teacher.deptNumber
    where deptName = IndeptName
    group by t.titleName;
end;

