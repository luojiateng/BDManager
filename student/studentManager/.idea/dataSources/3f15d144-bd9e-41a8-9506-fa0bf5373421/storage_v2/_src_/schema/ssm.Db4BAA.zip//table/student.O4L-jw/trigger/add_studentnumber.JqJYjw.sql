create definer = root@localhost trigger add_studentNumber
    after insert
    on student
    for each row
begin
    update classinfo set studentNumber=studentNumber + 1 where classId = NEW.classInfo;
end;

