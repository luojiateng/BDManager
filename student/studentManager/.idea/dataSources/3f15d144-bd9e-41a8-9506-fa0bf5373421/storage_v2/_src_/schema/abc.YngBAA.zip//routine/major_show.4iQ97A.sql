create
    definer = root@localhost procedure major_show()
begin
    select major_id as id, major_name as majorName, a.allStu as stuNumber, g.allStu as girlNumber, b.allStu as boyNumber,faculty_name
    from major
             right outer join (select count(*) as allStu, m.major_id as aid
                               from student s
                                        inner join classinfo c on c.class_id = s.class_id
                                        inner join major m on m.major_id = c.major_id
                                        inner join faculty f on f.faculty_id = m.faculty_id
                               group by major_name) a
                              on major.major_id = a.aid
             right outer join (select count(*) as allStu, m.major_id as bid
                               from student s
                                        inner join classinfo c on c.class_id = s.class_id
                                        inner join major m on m.major_id = c.major_id
                                        inner join faculty f on f.faculty_id = m.faculty_id
                               where s.gender = '男'
                               group by major_name) b
                              on b.bid = major.major_id
             right outer join (select count(*) as allStu, m.major_id as gid
                               from student s
                                        inner join classinfo c on c.class_id = s.class_id
                                        inner join major m on m.major_id = c.major_id
                                        inner join faculty f on f.faculty_id = m.faculty_id
                               where s.gender = '女'
                               group by major_name) g
                              on g.gid = major.major_id
    inner  join faculty f2 on f2.faculty_id = major.faculty_id
    order by id;
end;

