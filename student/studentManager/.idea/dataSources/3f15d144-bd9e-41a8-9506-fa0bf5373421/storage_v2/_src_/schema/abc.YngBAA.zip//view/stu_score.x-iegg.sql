create definer = root@localhost view stu_score as
select `abc`.`student`.`stu_id`   AS `stu_id`,
       `abc`.`student`.`stu_name` AS `stu_name`,
       `ss`.`course_name`         AS `course_name`,
       `ss`.`score`               AS `score`
from (`abc`.`student`
         left join (select `stu`.`stu_id`     AS `stu_id`,
                           `stu`.`stu_name`   AS `stu_name`,
                           `c2`.`course_name` AS `course_name`,
                           `s`.`score`        AS `score`
                    from (((`abc`.`student` `stu` join `abc`.`score` `s` on ((`s`.`stu_id` = `stu`.`stu_id`))) join `abc`.`classinfo` `c` on ((`stu`.`class_id` = `c`.`class_id`)))
                             join `abc`.`course` `c2` on ((`s`.`course_id` = `c2`.`course_id`)))
                    order by `stu`.`stu_id`) `ss` on ((`ss`.`stu_id` = `abc`.`student`.`stu_id`)));

