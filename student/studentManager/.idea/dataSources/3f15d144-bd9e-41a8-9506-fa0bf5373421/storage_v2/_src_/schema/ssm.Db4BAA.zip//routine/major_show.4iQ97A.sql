create
    definer = root@localhost procedure major_show()
begin
    select major.majorId, major.majorName, a.studentNumber, g.grilNumber, b.boyNumber, faculty.facultyName
    from (select major.majorId, count(*) as boyNumber
          from student
                   inner join classinfo
                   inner join major
                   inner join faculty
          where student.classInfo = classinfo.classId
            and classInfo.major = major.majorId
            and student.gender = '男'
          group by major) b
             inner join (select major.majorId, count(*) as grilNumber
                         from student
                                  inner join classinfo
                                  inner join major
                                  inner join faculty
                         where student.classInfo = classinfo.classId
                           and classInfo.major = major.majorId
                           and student.gender = '女'
                         group by major) g
             inner join(select major.majorId, count(*) as studentNumber
                        from student
                                 inner join classinfo
                                 inner join major
                                 inner join faculty
                        where student.classInfo = classinfo.classId
                          and classInfo.major = major.majorId
                        group by major) a
             inner join faculty
             inner join major
    where a.majorId = major.majorId
      and b.majorId = major.majorId
      and g.majorId = major.majorId
      and major.faculty = faculty.facultyId;
end;

