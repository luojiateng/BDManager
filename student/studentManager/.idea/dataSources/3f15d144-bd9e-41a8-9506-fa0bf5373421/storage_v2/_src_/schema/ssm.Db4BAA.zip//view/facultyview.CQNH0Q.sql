create definer = root@localhost view facultyview as
select `ssm`.`faculty`.`facultyId`   AS `facultyId`,
       `ssm`.`faculty`.`facultyName` AS `facultyName`,
       `a`.`studentNumber`           AS `studentNumber`,
       `g`.`girlNumber`              AS `girlNumber`,
       `b`.`boyNumber`               AS `boyNumber`
from (((((((select count(0) AS `girlNumber`, `ssm`.`faculty`.`facultyId` AS `facultyid`
            from (((`ssm`.`student` join `ssm`.`classinfo`) join `ssm`.`major`)
                     join `ssm`.`faculty`)
            where ((`ssm`.`student`.`classInfo` = `ssm`.`classinfo`.`classId`) and
                   (`ssm`.`classinfo`.`major` = `ssm`.`major`.`majorId`) and
                   (`ssm`.`major`.`faculty` = `ssm`.`faculty`.`facultyId`) and (`ssm`.`student`.`gender` = '女'))
            group by `ssm`.`major`.`faculty`)) `g` join (select count(0)                    AS `boyNumber`,
                                                                `ssm`.`faculty`.`facultyId` AS `facultyid`
                                                         from (((`ssm`.`student` join `ssm`.`classinfo`) join `ssm`.`major`)
                                                                  join `ssm`.`faculty`)
                                                         where ((`ssm`.`student`.`classInfo` = `ssm`.`classinfo`.`classId`) and
                                                                (`ssm`.`classinfo`.`major` = `ssm`.`major`.`majorId`) and
                                                                (`ssm`.`major`.`faculty` = `ssm`.`faculty`.`facultyId`) and
                                                                (`ssm`.`student`.`gender` = '男'))
                                                         group by `ssm`.`major`.`faculty`) `b`) join (select count(0)                    AS `studentNumber`,
                                                                                                             `ssm`.`faculty`.`facultyId` AS `facultyid`
                                                                                                      from (((`ssm`.`student` join `ssm`.`classinfo`) join `ssm`.`major`)
                                                                                                               join `ssm`.`faculty`)
                                                                                                      where ((`ssm`.`student`.`classInfo` = `ssm`.`classinfo`.`classId`) and
                                                                                                             (`ssm`.`classinfo`.`major` = `ssm`.`major`.`majorId`) and
                                                                                                             (`ssm`.`major`.`faculty` = `ssm`.`faculty`.`facultyId`))
                                                                                                      group by `ssm`.`major`.`faculty`) `a`) join `ssm`.`classinfo`) join `ssm`.`major`)
         join `ssm`.`faculty`)
where ((`a`.`facultyid` = `ssm`.`faculty`.`facultyId`) and (`g`.`facultyid` = `ssm`.`faculty`.`facultyId`) and
       (`b`.`facultyid` = `ssm`.`faculty`.`facultyId`) and (`ssm`.`classinfo`.`major` = `ssm`.`major`.`majorId`) and
       (`ssm`.`major`.`faculty` = `ssm`.`faculty`.`facultyId`))
group by `ssm`.`faculty`.`facultyName`
order by `ssm`.`faculty`.`facultyId`;

