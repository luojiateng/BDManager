create definer = root@localhost view studentview as
select `ssm`.`student`.`studentId`   AS `studentId`,
       `ssm`.`student`.`studentName` AS `studentName`,
       `ssm`.`student`.`gender`      AS `gender`,
       `ssm`.`classinfo`.`className` AS `className`,
       `ssm`.`major`.`majorName`     AS `majorName`,
       `ssm`.`faculty`.`facultyName` AS `facultyName`,
       `ssm`.`student`.`GPA`         AS `GPA`,
       `ssm`.`student`.`award`       AS `award`,
       `ssm`.`student`.`sacution`    AS `sacution`
from (((`ssm`.`student` join `ssm`.`classinfo`) join `ssm`.`major`)
         join `ssm`.`faculty`)
where ((`ssm`.`student`.`classInfo` = `ssm`.`classinfo`.`classId`) and
       (`ssm`.`classinfo`.`major` = `ssm`.`major`.`majorId`) and
       (`ssm`.`major`.`faculty` = `ssm`.`faculty`.`facultyId`))
order by `ssm`.`student`.`studentId`;

