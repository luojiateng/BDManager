create definer = root@localhost view classview as
select `ssm`.`classinfo`.`classId`   AS `classId`,
       `ssm`.`classinfo`.`className` AS `className`,
       `a`.`studentNumber`           AS `studentNumber`,
       `g`.`grilNumber`              AS `grilNumber`,
       `b`.`boyNumber`               AS `boyNumber`,
       `ssm`.`major`.`majorName`     AS `majorName`,
       `ssm`.`faculty`.`facultyName` AS `facultyName`
from (((((((select `ssm`.`student`.`classInfo`   AS `classId`,
                   count(0)                      AS `boyNumber`,
                   `ssm`.`classinfo`.`className` AS `className`
            from (`ssm`.`student`
                     join `ssm`.`classinfo`)
            where ((`ssm`.`student`.`classInfo` = `ssm`.`classinfo`.`classId`) and (`ssm`.`student`.`gender` = '男'))
            group by `ssm`.`student`.`classInfo`)) `b` join (select `ssm`.`student`.`classInfo`   AS `classId`,
                                                                    count(0)                      AS `grilNumber`,
                                                                    `ssm`.`classinfo`.`className` AS `className`
                                                             from (`ssm`.`student`
                                                                      join `ssm`.`classinfo`)
                                                             where ((`ssm`.`student`.`classInfo` = `ssm`.`classinfo`.`classId`) and
                                                                    (`ssm`.`student`.`gender` = '女'))
                                                             group by `ssm`.`student`.`classInfo`) `g`) join (select `ssm`.`student`.`classInfo`   AS `classId`,
                                                                                                                     count(0)                      AS `studentNumber`,
                                                                                                                     `ssm`.`classinfo`.`className` AS `className`
                                                                                                              from (`ssm`.`student`
                                                                                                                       join `ssm`.`classinfo`)
                                                                                                              where (`ssm`.`student`.`classInfo` = `ssm`.`classinfo`.`classId`)
                                                                                                              group by `ssm`.`student`.`classInfo`) `a`) join `ssm`.`classinfo`) join `ssm`.`major`)
         join `ssm`.`faculty`)
where ((`a`.`classId` = `ssm`.`classinfo`.`classId`) and (`b`.`classId` = `ssm`.`classinfo`.`classId`) and
       (`g`.`classId` = `ssm`.`classinfo`.`classId`) and (`ssm`.`classinfo`.`major` = `ssm`.`major`.`majorId`) and
       (`ssm`.`major`.`faculty` = `ssm`.`faculty`.`facultyId`));

