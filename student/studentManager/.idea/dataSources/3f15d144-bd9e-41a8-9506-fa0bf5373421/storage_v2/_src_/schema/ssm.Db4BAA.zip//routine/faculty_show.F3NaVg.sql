create
    definer = root@localhost procedure faculty_show()
begin
    select faculty.facultyId, faculty.facultyName, a.studentNumber, g.girlNumber, b.boyNumber
    from (select count(*) as girlNumber, facultyid
          from student
                   inner join classinfo
                   inner join major
                   inner join faculty
          where student.classInfo = classinfo.classId
            and classInfo.major = major.majorId
            and major.faculty = faculty.facultyId
            and student.gender = '女'
          group by faculty) g
             inner join (select count(*) as boyNumber, facultyid
                         from student
                                  inner join classinfo
                                  inner join major
                                  inner join faculty
                         where student.classInfo = classinfo.classId
                           and classInfo.major = major.majorId
                           and major.faculty = faculty.facultyId
                           and student.gender = '男'
                         group by faculty) b
             inner join (select count(*) as studentNumber, facultyid
                         from student
                                  inner join classinfo
                                  inner join major
                                  inner join faculty
                         where student.classInfo = classinfo.classId
                           and classInfo.major = major.majorId
                           and major.faculty = faculty.facultyId
                         group by faculty) a
             inner join classinfo
             inner join major
             inner join faculty
    where a.facultyId = faculty.facultyId
      and g.facultyId = faculty.facultyId
      and b.facultyId = faculty.facultyId
      and classinfo.major = major.majorId
      and major.faculty = faculty.facultyId
    group by facultyName
    order by facultyId;
end;

