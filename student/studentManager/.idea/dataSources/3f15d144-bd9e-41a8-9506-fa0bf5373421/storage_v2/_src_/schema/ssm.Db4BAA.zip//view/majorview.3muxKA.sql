create definer = root@localhost view majorview as
select `ssm`.`major`.`majorId`       AS `majorId`,
       `ssm`.`major`.`majorName`     AS `majorName`,
       `a`.`studentNumber`           AS `studentNumber`,
       `g`.`grilNumber`              AS `grilNumber`,
       `b`.`boyNumber`               AS `boyNumber`,
       `ssm`.`faculty`.`facultyName` AS `facultyName`
from ((((((select `ssm`.`major`.`majorId` AS `majorId`, count(0) AS `boyNumber`
           from (((`ssm`.`student` join `ssm`.`classinfo`) join `ssm`.`major`)
                    join `ssm`.`faculty`)
           where ((`ssm`.`student`.`classInfo` = `ssm`.`classinfo`.`classId`) and
                  (`ssm`.`classinfo`.`major` = `ssm`.`major`.`majorId`) and (`ssm`.`student`.`gender` = '男'))
           group by `ssm`.`classinfo`.`major`)) `b` join (select `ssm`.`major`.`majorId` AS `majorId`, count(0) AS `grilNumber`
                                                          from (((`ssm`.`student` join `ssm`.`classinfo`) join `ssm`.`major`)
                                                                   join `ssm`.`faculty`)
                                                          where ((`ssm`.`student`.`classInfo` = `ssm`.`classinfo`.`classId`) and
                                                                 (`ssm`.`classinfo`.`major` = `ssm`.`major`.`majorId`) and
                                                                 (`ssm`.`student`.`gender` = '女'))
                                                          group by `ssm`.`classinfo`.`major`) `g`) join (select `ssm`.`major`.`majorId` AS `majorId`,
                                                                                                                count(0)                AS `studentNumber`
                                                                                                         from (((`ssm`.`student` join `ssm`.`classinfo`) join `ssm`.`major`)
                                                                                                                  join `ssm`.`faculty`)
                                                                                                         where ((`ssm`.`student`.`classInfo` = `ssm`.`classinfo`.`classId`) and
                                                                                                                (`ssm`.`classinfo`.`major` = `ssm`.`major`.`majorId`))
                                                                                                         group by `ssm`.`classinfo`.`major`) `a`) join `ssm`.`faculty`)
         join `ssm`.`major`)
where ((`a`.`majorId` = `ssm`.`major`.`majorId`) and (`b`.`majorId` = `ssm`.`major`.`majorId`) and
       (`g`.`majorId` = `ssm`.`major`.`majorId`) and (`ssm`.`major`.`faculty` = `ssm`.`faculty`.`facultyId`))
order by `ssm`.`major`.`majorId`;

