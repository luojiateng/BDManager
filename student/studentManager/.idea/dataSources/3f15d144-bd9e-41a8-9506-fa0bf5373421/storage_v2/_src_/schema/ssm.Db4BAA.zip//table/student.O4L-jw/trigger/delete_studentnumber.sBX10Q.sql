create definer = root@localhost trigger delete_studentNumber
    after delete
    on student
    for each row
begin
    update classinfo set studentNumber=studentNumber - 1 where classId = OLD.classInfo;
end;

