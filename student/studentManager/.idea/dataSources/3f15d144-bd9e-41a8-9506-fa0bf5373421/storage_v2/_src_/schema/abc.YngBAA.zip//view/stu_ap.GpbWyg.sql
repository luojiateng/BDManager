create definer = root@localhost view stu_ap as
select `abc`.`award_punish`.`ap_id`      AS `ap_id`,
       `abc`.`award_punish`.`student_id` AS `student_id`,
       `s`.`stu_name`                    AS `stu_name`,
       `a`.`ap_type`                     AS `ap_type`,
       `abc`.`award_punish`.`time`       AS `time`,
       `abc`.`award_punish`.`desc`       AS `desc`
from ((`abc`.`award_punish` join `abc`.`ap_type` `a` on ((`a`.`ap_id` = `abc`.`award_punish`.`ap_type`)))
         join `abc`.`student` `s` on ((`s`.`stu_id` = `abc`.`award_punish`.`student_id`)))
order by `s`.`stu_id`;

