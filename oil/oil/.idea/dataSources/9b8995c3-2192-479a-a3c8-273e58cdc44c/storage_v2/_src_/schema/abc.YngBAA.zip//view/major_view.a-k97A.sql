create definer = root@localhost view major_view as
select `abc`.`major`.`major_id`   AS `major_id`,
       `abc`.`major`.`major_name` AS `majorname`,
       `allm`.`stuNumber`         AS `stuNumber`,
       `allm`.`girlNumber`        AS `girlNumber`,
       `allm`.`boyNumber`         AS `boyNumber`,
       `allm`.`faculty_name`      AS `faculty_name`
from (`abc`.`major`
         left join (select `abc`.`major`.`major_id`   AS `id`,
                           `abc`.`major`.`major_name` AS `majorName`,
                           `a`.`allStu`               AS `stuNumber`,
                           `g`.`allStu`               AS `girlNumber`,
                           `b`.`allStu`               AS `boyNumber`,
                           `f2`.`faculty_name`        AS `faculty_name`
                    from ((((select count(0) AS `allStu`, `m`.`major_id` AS `gid`
                             from (((`abc`.`student` `s` join `abc`.`classinfo` `c` on ((`c`.`class_id` = `s`.`class_id`))) join `abc`.`major` `m` on ((`m`.`major_id` = `c`.`major_id`)))
                                      join `abc`.`faculty` `f` on ((`f`.`faculty_id` = `m`.`faculty_id`)))
                             where (`s`.`gender` = '女')
                             group by `m`.`major_name`)) `g` left join (((select count(0) AS `allStu`, `m`.`major_id` AS `bid`
                                                                          from (((`abc`.`student` `s` join `abc`.`classinfo` `c` on ((`c`.`class_id` = `s`.`class_id`))) join `abc`.`major` `m` on ((`m`.`major_id` = `c`.`major_id`)))
                                                                                   join `abc`.`faculty` `f` on ((`f`.`faculty_id` = `m`.`faculty_id`)))
                                                                          where (`s`.`gender` = '男')
                                                                          group by `m`.`major_name`)) `b` left join (((select count(0) AS `allStu`, `m`.`major_id` AS `aid`
                                                                                                                       from (((`abc`.`student` `s` join `abc`.`classinfo` `c` on ((`c`.`class_id` = `s`.`class_id`))) join `abc`.`major` `m` on ((`m`.`major_id` = `c`.`major_id`)))
                                                                                                                                join `abc`.`faculty` `f` on ((`f`.`faculty_id` = `m`.`faculty_id`)))
                                                                                                                       group by `m`.`major_name`)) `a` left join `abc`.`major` on ((`abc`.`major`.`major_id` = `a`.`aid`))) on ((`b`.`bid` = `abc`.`major`.`major_id`))) on ((`g`.`gid` = `abc`.`major`.`major_id`)))
                             join `abc`.`faculty` `f2` on ((`f2`.`faculty_id` = `abc`.`major`.`faculty_id`)))
                    order by `id`) `allm` on ((`abc`.`major`.`major_id` = `allm`.`id`)));

