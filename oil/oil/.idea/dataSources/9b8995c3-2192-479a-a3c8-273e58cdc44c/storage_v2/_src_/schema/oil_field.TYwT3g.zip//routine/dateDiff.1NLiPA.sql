create
    definer = root@localhost procedure dateDiff(IN cnumber varchar(255))
begin
    SELECT CONCAT(
                   FLOOR(seconds / 86400), '天',
                   FLOOR(seconds % 86400 / 3600), '小时',
                   FLOOR((seconds % 3600) / 60), '分钟',
                   FLOOR((seconds % 3600) % 60), '秒'
               ) AS RTS
    FROM (
             SELECT IFNULL(TIMESTAMPDIFF(SECOND, Octime, Retime), 0) AS seconds
             FROM accident
             where accident.Cnumber = cnumber
         ) AS t;
end;

