create definer = root@localhost view well_accident as
select `oil_field`.`well`.`cnumber` AS `cnumber`,
       `oil_field`.`well`.`wnumber` AS `wnumber`,
       `oil_field`.`well`.`oname`   AS `oname`,
       `a`.`Indepth`                AS `Indepth`,
       `a`.`Endepth`                AS `Endepth`,
       `a`.`Encoding`               AS `Encoding`,
       `a`.`Gfloor`                 AS `Gfloor`,
       `a`.`Stratum`                AS `Stratum`,
       `a`.`Octime`                 AS `Octime`,
       `a`.`Retime`                 AS `Retime`,
       `a`.`Lossmoney`              AS `Lossmoney`,
       `a`.`pass`                   AS `pass`,
       `e`.`Apattern`               AS `Apattern`
from ((`oil_field`.`accident` `a` left join `oil_field`.`well` on ((`oil_field`.`well`.`cnumber` = `a`.`Cnumber`)))
         join `oil_field`.`encoding` `e` on ((`a`.`Encoding` = convert(`e`.`Encoding_id` using utf8mb4))));

-- comment on column well_accident.Apattern not supported: 事故类型

