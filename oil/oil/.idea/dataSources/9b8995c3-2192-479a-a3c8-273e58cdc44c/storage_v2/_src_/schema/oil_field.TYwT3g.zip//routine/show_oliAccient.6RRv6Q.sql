create
    definer = root@localhost procedure show_oliAccient(IN oilname varchar(30))
begin
    select count(*) as AccidentCount, oname
    from accident
             inner join well on accident.Cnumber = well.cnumber
    where oname = oilname
    group by oname;
end;

