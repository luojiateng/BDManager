create
    definer = root@localhost procedure show_wellAccident(IN wellNumber int)
begin
    select count(*) as AccidentCount, wnumber
    from accident
             inner join well w on accident.Cnumber = w.cnumber
    where wnumber = wellNumber
    group by wnumber;
end;

