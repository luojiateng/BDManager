create definer = root@localhost view faculty_view as
select `abc`.`faculty`.`faculty_id`   AS `faculty_id`,
       `abc`.`faculty`.`faculty_name` AS `faculty_name`,
       `aaaa`.`stuCount`              AS `stuCount`,
       `aaaa`.`girlCount`             AS `girlCount`,
       `aaaa`.`boyCount`              AS `boyCount`
from (`abc`.`faculty`
         left join (select `abc`.`faculty`.`faculty_id`   AS `faculty_id`,
                           `abc`.`faculty`.`faculty_name` AS `faculty_name`,
                           `al`.`acount`                  AS `stuCount`,
                           `g`.`gcount`                   AS `girlCount`,
                           `b`.`bcount`                   AS `boyCount`
                    from ((select count(0) AS `gcount`, `f`.`faculty_id` AS `gid`
                           from (((`abc`.`student` `s` join `abc`.`classinfo` `c` on ((`c`.`class_id` = `s`.`class_id`))) join `abc`.`major` `m` on ((`m`.`major_id` = `c`.`major_id`)))
                                    join `abc`.`faculty` `f` on ((`f`.`faculty_id` = `m`.`faculty_id`)))
                           where (`s`.`gender` = '女')
                           group by `f`.`faculty_id`) `g`
                             left join ((select count(0) AS `bcount`, `f`.`faculty_id` AS `bid`
                                         from (((`abc`.`student` `s` join `abc`.`classinfo` `c` on ((`c`.`class_id` = `s`.`class_id`))) join `abc`.`major` `m` on ((`m`.`major_id` = `c`.`major_id`)))
                                                  join `abc`.`faculty` `f` on ((`f`.`faculty_id` = `m`.`faculty_id`)))
                                         where (`s`.`gender` = '男')
                                         group by `f`.`faculty_id`) `b` left join ((select count(0) AS `acount`, `f`.`faculty_id` AS `aid`
                                                                                    from (((`abc`.`student` `s` join `abc`.`classinfo` `c` on ((`c`.`class_id` = `s`.`class_id`))) join `abc`.`major` `m` on ((`m`.`major_id` = `c`.`major_id`)))
                                                                                             join `abc`.`faculty` `f` on ((`f`.`faculty_id` = `m`.`faculty_id`)))
                                                                                    group by `f`.`faculty_id`) `al` left join `abc`.`faculty` on ((`al`.`aid` = `abc`.`faculty`.`faculty_id`))) on ((`b`.`bid` = `abc`.`faculty`.`faculty_id`)))
                                       on ((`g`.`gid` = `abc`.`faculty`.`faculty_id`)))) `aaaa`
                   on ((`abc`.`faculty`.`faculty_id` = `aaaa`.`faculty_id`)))
order by `abc`.`faculty`.`faculty_id`;

