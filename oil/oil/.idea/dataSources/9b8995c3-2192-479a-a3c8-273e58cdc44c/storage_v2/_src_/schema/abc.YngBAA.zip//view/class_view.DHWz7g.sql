create definer = root@localhost view class_view as
select `abc`.`classinfo`.`class_id`   AS `class_id`,
       `abc`.`classinfo`.`name`       AS `classname`,
       `abc`.`classinfo`.`stu_number` AS `stu_number`,
       `m`.`major_name`               AS `major_name`,
       `f`.`faculty_name`             AS `faculty_name`
from ((`abc`.`classinfo` join `abc`.`major` `m` on ((`m`.`major_id` = `abc`.`classinfo`.`major_id`)))
         join `abc`.`faculty` `f` on ((`f`.`faculty_id` = `m`.`faculty_id`)))
order by `abc`.`classinfo`.`class_id`;

