create definer = root@localhost view allstu_view as
select `s`.`stu_id`       AS `id`,
       `s`.`stu_name`     AS `studentname`,
       `s`.`gender`       AS `gender`,
       `c`.`name`         AS `className`,
       `m`.`major_name`   AS `major`,
       `f`.`faculty_name` AS `faculty`
from (((`abc`.`student` `s` join `abc`.`classinfo` `c` on ((`c`.`class_id` = `s`.`class_id`))) join `abc`.`major` `m` on ((`m`.`major_id` = `c`.`major_id`)))
         join `abc`.`faculty` `f` on ((`f`.`faculty_id` = `m`.`faculty_id`)))
order by `s`.`stu_id`;

